import axios from 'axios';
import React, {useState, useEffect} from 'react';
import {StyleSheet, View, Text, FlatList} from 'react-native';

const TipsScreen = () => {
  const [tips, setTips] = useState([]);

  // useEffect(() => {
  //   fetch('https://symptoms3.onrender.com/tips')
  //     .then(response => response.json())
  //     .then(data => setTips(data.tips.tips))
  //     .catch(error => console.error(error));
  // }, []);

  // get tips from api using axios

  useEffect(() => {
    axios
      .get('https://symptoms3.onrender.com/tips')
      .then(response => {
        console.log(response.data.tips.tips, 'response');
        setTips(response.data.tips.tips);
      })
      .catch(error => {
        console.log(error);
      });
  }, []);

  console.log(tips, 'tips');

  const tipss = [
    {
      title: 'Stay Hydrated',
      description:
        'Drink at least 8 cups of water a day to keep your body hydrated and functioning properly.',
      category: 'General Health',
    },
    {
      title: 'Exercise Regularly',
      description:
        'Try to get at least 30 minutes of exercise every day to improve your overall health and well-being.',
      category: 'Fitness',
    },
    {
      title: 'Get Enough Sleep',
      description:
        'Make sure to get 7-9 hours of sleep every night to give your body the rest it needs to function properly.',
      category: 'Sleep',
    },
    {
      title: 'Eat a Balanced Diet',
      description:
        'Aim to eat a variety of foods from all food groups to get the nutrients your body needs to stay healthy.',
      category: 'Nutrition',
    },
    {
      title: 'Wash Your Hands',
      description:
        'Wash your hands frequently with soap and water or use hand sanitizer to prevent the spread of germs.',
      category: 'Hygiene',
    },
  ];

  const renderTip = ({item}) => (
    <View style={styles.tipContainer}>
      <Text style={styles.tipTitle}>{item.title}</Text>
      <Text style={styles.tipDescription}>{item.description}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Health Tips</Text>
      <FlatList
        data={tipss}
        renderItem={renderTip}
        keyExtractor={item => item._id}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  tipContainer: {
    backgroundColor: '#ffffff',
    borderRadius: 5,
    marginBottom: 10,
    padding: 10,
  },
  tipTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  tipDescription: {
    fontSize: 16,
  },
});

export default TipsScreen;
