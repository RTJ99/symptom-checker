import {Icon, Image} from 'native-base';
import React, {useState} from 'react';
import {View, Text} from 'react-native';
import {Button} from 'react-native-elements';
import {CheckBox} from 'react-native-elements';
import {SafeAreaView} from 'react-native-safe-area-context';

const SymptomChecker = () => {
  const symptoms = [
    {label: 'Fever', value: 'fever'},
    {label: 'Cough', value: 'cough'},
    {label: 'Sore throat', value: 'soreThroat'},
    {label: 'Shortness of breath', value: 'shortnessOfBreath'},
    {label: 'Fatigue', value: 'fatigue'},
    {label: 'Headache', value: 'headache'},
    {label: 'Muscle aches', value: 'muscleAches'},
    {label: 'Runny nose', value: 'runnyNose'},
    {label: 'Loss of taste or smell', value: 'lossOfTasteOrSmell'},
  ];

  const conditions = [
    {
      name: 'COVID-19',
      symptoms: [
        'fever',
        'cough',
        'shortnessOfBreath',
        'fatigue',
        'lossOfTasteOrSmell',
      ],
    },
    {name: 'Common cold', symptoms: ['cough', 'soreThroat', 'runnyNose']},
    {
      name: 'Flu',
      symptoms: ['fever', 'cough', 'fatigue', 'muscleAches', 'headache'],
    },
    {
      name: 'Pneumonia',
      symptoms: ['fever', 'cough', 'shortnessOfBreath', 'fatigue'],
    },
    {name: 'Migraine', symptoms: ['headache', 'nausea']},
  ];

  const getConditionProbability = selectedSymptoms => {
    const matchedConditions = conditions.filter(condition => {
      const matchedSymptoms = selectedSymptoms.filter(symptom =>
        condition.symptoms.includes(symptom.value),
      );
      return matchedSymptoms.length === selectedSymptoms.length;
    });

    const probabilities = matchedConditions.map(condition => {
      const probability =
        (selectedSymptoms.length / condition.symptoms.length) * 100;
      return {
        condition: condition.name,
        probability: probability.toFixed(2) + '%',
      };
    });

    return probabilities;
  };

  const [selectedSymptoms, setSelectedSymptoms] = useState([]);

  const handleSymptomSelection = symptom => {
    const updatedSymptoms = [...selectedSymptoms];
    const symptomIndex = updatedSymptoms.indexOf(symptom);
    if (symptomIndex >= 0) {
      updatedSymptoms.splice(symptomIndex, 1);
    } else {
      updatedSymptoms.push(symptom);
    }
    setSelectedSymptoms(updatedSymptoms);
  };
  const handleCheckSymptoms = () => {
    const matchedConditions = conditions.filter(condition =>
      condition.symptoms.every(symptom => selectedSymptoms.includes(symptom)),
    );

    if (matchedConditions.length === 0) {
      alert('No match found. Please consult a doctor.');
    } else if (matchedConditions.length === 1) {
      const {name} = matchedConditions[0];
      alert(`You may have ${name}. Please consult a doctor for confirmation.`);
    } else {
      const names = matchedConditions.map(condition => condition.name);
      alert(
        `You may have one of the following: ${names.join(
          ', ',
        )}. Please consult a doctor for confirmation.`,
      );
    }
  };

  const clearSymptoms = () => {
    setSelectedSymptoms([]);
  };
  const renderSymptomOption = symptom => {
    return (
      <CheckBox
        style={{
          borderRadius: 10,
        }}
        checkedIcon={
          <Image
            alt="check"
            style={{
              width: 20,
              height: 20,
            }}
            source={require('../../assets/check.png')}
          />
        }
        uncheckedIcon={<Icon name="check-box-outline-blank" />}
        checked={selectedSymptoms.indexOf(symptom.value) >= 0}
        key={symptom.value}
        // value={selectedSymptoms.indexOf(symptom.value) >= 0}
        // onValueChange={() => handleSymptomSelection(symptom.value)}
        title={symptom.label}
        onPress={() => handleSymptomSelection(symptom.value)}
      />
    );
  };

  return (
    <SafeAreaView>
      <View
        style={{
          padding: 20,
        }}>
        <Text
          style={{
            fontSize: 26,
            fontWeight: '700',
            marginTop: 10,
            paddingHorizontal: 40,
            margin: 'auto',
            color: 'black',
            textAlign: 'center',
          }}>
          Select your symptoms:
        </Text>
        {symptoms.map(renderSymptomOption)}
        <View
          style={{
            marginTop: 20,
            marginHorizontal: 40,
          }}>
          <Button
            buttonStyle={{
              marginBottom: 10,
            }}
            icon={<Icon name="Search" size={15} color="white" />}
            title="Check symptoms"
            onPress={handleCheckSymptoms}
          />
        </View>
        <View
          style={{
            marginTop: 20,
          }}>
          <Button
            style={{
              marginTop: 10,
            }}
            type="clear"
            title="Clear symptoms"
            onPress={clearSymptoms}
          />
        </View>
      </View>
    </SafeAreaView>
  );
};

export default SymptomChecker;
