const colors = {
  primary: '#00b894',
  muted: '#f1f1f1',
  white: '#FFF',
  dark: '#222',
  light: '#e1e1e3',
  grey: '#A9A9A9',
  blue: '#2e2f91',
  red: 'red',
  tranparent: 'rgba(0,0,0,0)',
};

export default colors;
